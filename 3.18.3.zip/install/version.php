<?php

$arModuleVersion = [
    "VERSION"      => "3.18.2",
    "VERSION_DATE" => "2021-09-08 10:30:00",
];
